<?php
/**
 * Controller por defecto si no se usa el routes
 * 
 */
class SitemapController extends AppController    { 
    public function index($page=1){
        
        View::Template(NULL);
        
            
//            SELECT * FROM clasificados ORDER BY id_clasi DESC LIMIT 0,100
    }
    
    
}
?>