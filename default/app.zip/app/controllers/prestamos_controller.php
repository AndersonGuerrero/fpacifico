<?php
Load::models("user","general","banner","servicios","empresa","sucursales","categorias","promociones","requisitos");

class PrestamosController extends AppController
{

    public function solicitud($id)
    {
    	View::template("solicitud");
    	$this->servicio = Load::model("servicios")->find_by_id($id);
    	$this->sucursales = Load::model("sucursales")->find();


    }

}
