<?php 
class Banner extends ActiveRecord{
}
?>