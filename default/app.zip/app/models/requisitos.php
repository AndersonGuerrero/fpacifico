<?php 
class Requisitos extends ActiveRecord{
}
?>