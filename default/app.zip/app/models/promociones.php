<?php 
class Promociones extends ActiveRecord{
}
?>