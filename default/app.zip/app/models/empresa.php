<?php 
class Empresa extends ActiveRecord{
}
?>