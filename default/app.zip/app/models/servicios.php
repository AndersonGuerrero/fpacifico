<?php 
class Servicios extends ActiveRecord{
}

 ?>