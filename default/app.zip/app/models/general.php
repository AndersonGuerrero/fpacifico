<?php 
class General extends ActiveRecord{
}

 ?>