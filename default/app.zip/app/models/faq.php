<?php 
class Faq extends ActiveRecord{
}
?>