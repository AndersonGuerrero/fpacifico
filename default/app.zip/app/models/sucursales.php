<?php 
class Sucursales extends ActiveRecord{
}
?>