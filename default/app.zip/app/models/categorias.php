<?php 
class Categorias extends ActiveRecord{
}
?>